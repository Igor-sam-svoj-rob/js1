"use strict";

// input eventi

/* const input = document.querySelector("#zadatak-input");
const naslov = document.querySelector("h1");

const naInput = (e) => {
  console.log(e.target.value);
  naslov.textContent = e.target.value;
};

const naFocus = () => {
  console.log("input je u fokusu");
};

const naBlur = () => {
  console.log("input nije u fokusu");
};

input.addEventListener("input", naInput);
input.addEventListener("focus", naFocus); // provjerava jesmo li kliknuli na input polje
input.addEventListener("blur", naBlur); // provjerava kad smo nakon klika na input polje kliknuli van input polja
 */
// Submit event

const forma = document.getElementById("zadatak-forma");

const onSubmit = (e) => {
  e.preventDefault();

  const zadatak = document.getElementById("zadatak-input");
  if (zadatak.value === "") {
    alert("Niste ispunili input polje");
    return;
  }
  console.log(zadatak.value);
};

forma.addEventListener("submit", onSubmit);

// Event bubbling

const gumb = document.querySelector("form button");
const div = document.querySelector("form div:nth-child(2)");
const forma1 = document.querySelector("form");

gumb.addEventListener("click", (e) => {
  alert("gumb je kliknut");
  e.stopPropagation(); // Ovo dodajemo kako bi spriječili izvođenje zapisano u event logu
});

div.addEventListener("click", () => {
  alert("div je kliknut");
});

forma1.addEventListener("click", () => {
  alert("forma je kliknuta");
});

const listaZadataka = document.querySelector("#zadatak-list");

listaZadataka.addEventListener("click", (e) => {
  if (e.target.className === "pojedinacni-zadatak") {
    e.target.remove();
  }
});

listaZadataka.addEventListener("mouseover", (e) => {
  if (e.target.className === "pojedinacni-zadatak") {
    e.target.style.color = "#ff0000";
  }
});

listaZadataka.addEventListener("mouseout", (e) => {
  if (e.target.className === "pojedinacni-zadatak") {
    e.target.style.color = "#000";
  }
});
