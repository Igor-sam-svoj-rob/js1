"use strict";

const clearBtn = document.querySelector("#clear");

/* clearBtn.addEventListener("click", function () {
  alert("Event listener");
}); */

/* clearBtn.addEventListener("click", () => {
  alert("Event listener");
  console.log("kliknuli smo na gumb.");
}); */

/* function eventLst() {
  console.log("Event listener");
}

clearBtn.addEventListener("click", eventLst); */

const pocisti = () => {
  const listaZadataka = document.querySelector(".zadatak");
  const zadaci = listaZadataka.querySelectorAll(".pojedinacni-zadatak");

  zadaci.forEach((zadatak) => {
    zadatak.remove();
  });
};

clearBtn.addEventListener("click", pocisti);

// Mouse evente

const naslov = document.querySelector("h1");

/* const lijeviKlik = () => console.log("lijevi klik");
const dupliKlik = () => console.log("dupli klik");
const stisniKlik = () => console.log("stisni i drži");
const pustiKlik = () => console.log("pusti klik");
const kotacicMisa = () => console.log("Kotacic miša");
const hoverIn = () => console.log("Hover in sa mišem");
const hoverOut = () => console.log("Hover out sa mišem");

naslov.addEventListener("click", lijeviKlik); // jedan klik mišem
naslov.addEventListener("dblclick", dupliKlik); // dupli klik mišem
naslov.addEventListener("mousedown", stisniKlik); // stisni i drži klik miša
naslov.addEventListener("mouseup", pustiKlik); // pustim klik miša
naslov.addEventListener("wheel", kotacicMisa); // kotačić miša
naslov.addEventListener("mouseover", hoverIn); // hover in
naslov.addEventListener("mouseout", hoverOut); // hover out */

// pointer evente

const pointerEvent = (e) => {
  console.log(e); // vidjet ćemo sve moguće pointer evente
  console.log(e.target); // Dat će nam HTML element koji smo kliknuli
  console.log(e.type); // Dat će nam vrstu eventa koji je aktiviran
  console.log(e.clientX); // Dat će nam vrijednost po horizontali relativno prema prozoru
  console.log(e.clientY); // Dat će nam vrijednost po vertikali relativno prema prozoru
  console.log(e.offsetX); // Dat će nam vrijednost po horizontali relativno prema elementu
  console.log(e.offsetY); // Dat će nam vrijednost po vertikali relativno prema elementu
  console.log(e.pageX); // Dat će nam vrijednost po horizontali relativno prema stranici
  console.log(e.pagey); // Dat će nam vrijednost po vertikali relativno prema stranici
  console.log(e.screenX); // Dat će nam vrijednost po horizontali relativno prema ekranu monitora
  console.log(e.screenY); // Dat će nam vrijednost po vertikali relativno prema ekranu monitora
};

naslov.addEventListener("click", pointerEvent);

/* Prevent Default metoda - spriječava defaultno ponašanje određenih HTML elemenata (pretežno gumbića),
kako bi spriječili refresh stranice prilikom klika na taj gumb, tj. ono što bi se po definiranom ponašanju 
dogodilo kada kliknemo na neki HTML gumb */

const filterBtn = document.querySelector(".btn");

filterBtn.addEventListener("click", (e) => {
  e.preventDefault();
  console.log("spriječili smo refresh");
});

// Drag event metoda

const para = document.querySelector("p");

const onDrag = (e) => {
  naslov.textContent = `X ${e.clientX} Y ${e.clientY}`;
};

para.addEventListener("drag", onDrag);

//Keyboard eventi

const input = document.querySelector("#zadatak-input");

const onKeyPress = (e) => {
  console.log(e.key);
};

const keyDown = (e) => {
  if (e.key === "Enter") {
    alert("Stisnuo si enter");
  }

  if (e.repeat) {
    alert("Skini se tipke");
  }
};

input.addEventListener("keypress", onKeyPress); // bilo što da se stisne clg će se
input.addEventListener("keyup", onKeyPress); // aktivirat će se kada pustimo prst sa tipke
input.addEventListener("keydown", keyDown); // čim stisnemo tipku će se aktivirati
