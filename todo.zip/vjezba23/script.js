"use strict";

/* Deklariranje varijabli */

/* localStorage metode

localStorage.setItem("kljuc", "vrijednost"); - sprema vrijednost sa pripadnim ključem
localStorage.getItem("kljuc") - dohvatit vrijednost zapisanu na traženom ključu
localStorage.removeItem("kljuc") - briše ključ i vrijednost na traženom ključu
localStorage.clear() - briše cijeli localStorage
*/

const forma = document.getElementById("zadatak-forma");
const zadatakInput = document.getElementById("zadatak-input");
const listaZadataka = document.getElementById("zadatak-list");
const brisiSve = document.getElementById("clear");
const filter = document.getElementById("filter");

// Povlačenje zadataka iz local storagea

const prikaziZadatkeLS = () => {
  const zadaciSpremiste = dohvatiLocaleStorage();
  zadaciSpremiste.forEach((zadatak) => kreirajZadatak(zadatak));
  provjeriListu();
};

/* Izrada zadatka */

const dodajZadatak = (e) => {
  e.preventDefault();

  const noviZadatak = zadatakInput.value;

  if (noviZadatak === "") {
    alert("Molimo Vas, unesite zadatak");
    return;
  }

  kreirajZadatak();

  provjeriListu();

  dodajLocalStorage(noviZadatak);

  zadatakInput.value = "";
};

/* Funkcija za kreiranje zadataka u HTML-u */

const kreirajZadatak = (noviZadatak) => {
  const li = document.createElement("li");
  li.appendChild(document.createTextNode(noviZadatak));
  li.className = "pojedinacni-zadatak";

  const delGumb = document.createElement("button");
  delGumb.className = "ukloni-zadatak btn-link";

  const ikonica = document.createElement("i");
  ikonica.className = "fa-solid fa-xmark";

  delGumb.appendChild(ikonica);
  li.appendChild(delGumb);
  listaZadataka.appendChild(li);
};

/* Dodavanje u local storage */

const dodajLocalStorage = (zadatakInput) => {
  const zadaciSpremiste = dohvatiLocaleStorage();
  zadaciSpremiste.push(zadatakInput);
  localStorage.setItem("kljuc", JSON.stringify(zadaciSpremiste));
};

/* Dohvaćanje iz local storagea */

const dohvatiLocaleStorage = () => {
  let zadaciSpremiste;

  if (localStorage.getItem("kljuc") === null) {
    zadaciSpremiste = [];
  } else {
    zadaciSpremiste = JSON.parse(localStorage.getItem("kljuc"));
  }
  return zadaciSpremiste;
};

/* Brisanje zadatka */

const obrisiZadatak = (e) => {
  if (e.target.parentElement.classList.contains("ukloni-zadatak")) {
    e.target.parentElement.parentElement.remove();
  }
  provjeriListu();
};

/* Brisanje svih zadataka */

const obrisiZadatke = (e) => {
  while (listaZadataka.firstChild) {
    listaZadataka.removeChild(listaZadataka.firstChild);
  }
  provjeriListu();
};

const filtrirajZadatke = (e) => {
  const zadaci = listaZadataka.querySelectorAll("li");
  const tekst = e.target.value.toLowerCase();

  zadaci.forEach((zadatak) => {
    const imeZadatka = zadatak.firstChild.textContent.toLowerCase();
    if (imeZadatka.indexOf(tekst) != -1) {
      zadatak.style.display = "flex";
    } else {
      zadatak.style.display = "none";
    }
  });
};

/* Provjera ima li štogod u listi i prikazivanje filtera i brisiSve gumba */

const provjeriListu = () => {
  const zadaci = listaZadataka.querySelectorAll("li");

  if (zadaci.length === 0) {
    filter.style.display = "none";
    brisiSve.style.display = "none";
  } else {
    filter.style.display = "block";
    brisiSve.style.display = "block";
  }
};

/* Event listeneri */

forma.addEventListener("submit", dodajZadatak);
listaZadataka.addEventListener("click", obrisiZadatak);
brisiSve.addEventListener("click", obrisiZadatke);
filter.addEventListener("input", filtrirajZadatke);
document.addEventListener("DOMContentLoaded", prikaziZadatkeLS);

/* Inicijalno pokretanje provjere liste */
provjeriListu();
