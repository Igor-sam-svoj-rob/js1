"use strict";

let podaci = [
  {
    ime: "Igor",
    godine: 40,
  },
  {
    ime: "Ivan",
    godine: 30,
  },
  {
    ime: "Jura",
    godine: 34,
  },
  {
    ime: "Stjepan",
    godine: 50,
  },
  {
    ime: "Marija",
    godine: 55,
  },
  {
    ime: "Maja",
    godine: 27,
  },
];

const info = document.querySelector("#info");

let lista = podaci.map((osoba) => {
  return `<div>${osoba.ime} ima ${osoba.godine} godina</div>`;
});

info.innerHTML = lista.join("");

/* Drugi primjer sa buttonom */

let index = 0;

const gumb = document.querySelector("button");

const promijeniBoju = () => {
  let boje = ["red", "blue", "green", "yellow", "azure", "orange", "purple"];
  document.body.style.backgroundColor = boje[index++];

  if (index > boje.length - 1) {
    index = 0;
  }
};

gumb.addEventListener("click", promijeniBoju);
