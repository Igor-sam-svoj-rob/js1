"use strict";

export let kosarica = [];
const dostava = 10;

export const dodajKosarica = function (proizvod, kolicina) {
  kosarica.push({ proizvod, kolicina });
  console.log(`${kolicina} ${proizvod} je dodan u košaricu`);
};
