"use strict";

/* import { kosarica, dodajKosarica } from "./cart.js"; */
import * as cart from "./cart.js";

cart.dodajKosarica("pašteta", 4);
cart.dodajKosarica("kruh", 1);

console.log(cart.kosarica);

const suma = cart.kosarica.reduce((prije, sad) => prije + sad.kolicina, 0);
console.log(suma);
