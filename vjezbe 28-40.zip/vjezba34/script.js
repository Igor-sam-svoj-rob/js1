"use strict";

document.getElementById("povuci").addEventListener("click", povuciTekst);

function povuciTekst() {
  fetch("./uzorak.txt")
    .then((res) => res.text())
    .then((data) => (document.getElementById("ispisi").innerHTML = data))
    .catch((error) => console.log(error));
}

document.getElementById("lokalni_json").addEventListener("click", povuciJson);

function povuciJson() {
  fetch("./users.json")
    .then((res) => res.json())
    .then((data) => {
      let ispis = `<h2>Korisnici</h2>`;

      data.forEach((user) => {
        ispis += `<ul>
            <li>ID: ${user.id}</li>
            <li>Ime: ${user.ime}</li>
            <li>Prezime: ${user.prezime}</li>
            </ul>`;
      });
      document.getElementById("ispisi").innerHTML = ispis;
    })
    .catch((error) => console.log(error));
}

document.getElementById("vanjski_json").addEventListener("click", povuciAPI);

function povuciAPI() {
  fetch("https://jsonplaceholder.typicode.com/posts")
    .then((res) => res.json())
    .then((data) => {
      let apiIspis = `<h2>API postovi</h2>`;

      data.forEach((post) => {
        apiIspis += `<div>
            <h3>${post.id}, ${post.title}</h3>
            <p>${post.body}</p>
            </div>`;
      });
      document.getElementById("ispisi").innerHTML = apiIspis;
    })
    .catch((error) => console.log(error));
}

document.getElementById("post").addEventListener("submit", dodajPost);

function dodajPost(e) {
  e.preventDefault();

  let naslov = document.getElementById("title").value;
  let tekst = document.getElementById("body").value;

  fetch("https://jsonplaceholder.typicode.com/posts", {
    method: "POST",
    headers: {
      "Content-type": "application/json",
    },
    body: JSON.stringify({ title: naslov, body: tekst }),
  })
    .then((res) => res.json())
    .then((data) => console.log(data));
}
