"use-strict";

const karticaTemplate = document.querySelector("template");
const kartice = document.querySelector(".user-cards");
const searchInput = document.getElementById("search");

let users = [];

searchInput.addEventListener("input", function (event) {
  const value = event.target.value.toLowerCase();
  users.forEach((user) => {
    const vidljiv =
      user.name.toLowerCase().includes(value) ||
      user.email.toLowerCase().includes(value);
    user.element.classList.toggle("sakrij", !vidljiv);
  });
});

fetch("https://jsonplaceholder.typicode.com/users")
  .then((res) => res.json())
  .then((data) => {
    users = data.map((clan_liste) => {
      const kartica = karticaTemplate.content.cloneNode(true).children[0];
      const header = kartica.querySelector(".header");
      const body = kartica.querySelector(".body");
      header.textContent = clan_liste.name;
      body.textContent = clan_liste.email;
      kartice.append(kartica);
      return {
        name: clan_liste.name,
        email: clan_liste.email,
        element: kartica,
      };
    });
  });
