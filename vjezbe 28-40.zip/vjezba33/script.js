"use strict";

const url = "https://jsonplaceholder.typicode.com/todos/1";

function dohvatiPodatke() {
  const odgovorAPI = fetch(url)
    .then((odgovorAPI) => odgovorAPI.json())
    .then((data) => (document.querySelector("h1").innerHTML = data.title));
}

dohvatiPodatke();

fetch("./filmovi.json")
  .then((response) => response.json())
  .then((podaci) => console.log(podaci));

fetch("./test.txt")
  .then((response) => response.text())
  .then((podaci) => console.log(podaci));

/* Vježba dohvaćanja slike random psa */

const pas_btn = document.getElementById("pas_btn");
const pas = document.getElementById("pas");

pas_btn.addEventListener("click", randomPas);

function randomPas() {
  fetch("https://random.dog/woof.json")
    .then((response) => response.json())
    .then((data) => {
      if (data.url.includes("mp4") || data.url.includes("webm")) {
        randomPas();
      } else {
        pas.innerHTML = `<img src=${data.url} alt="pas" />`;
      }
    });
}

randomPas();

function kreirajPost({ title, body }) {
  fetch("https://jsonplaceholder.typicode.com/posts", {
    method: "POST",
    headers: {
      "Content-type": "application/json",
      token: "abc123",
    },
    body: JSON.stringify({
      title,
      body,
    }),
  })
    .then((res) => res.json())
    .then((data) => console.log(data));
}

kreirajPost({ title: "Ovo je moj post", body: "Ovo smo mi ubacili" });
