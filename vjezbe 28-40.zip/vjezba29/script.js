"use strict";

/* HTTP metode:
GET, POST, PUT&PATCH (EDIT), DELETE zahtjev.

GET - traži podatke sa servera
POST - šalje podatke na server
PUT&PATCH (EDIT) - updatea podatke na serveru
DELETE - briše podatke sa servera */

/* HTTP status kodovi:

100 - continue

200 - uspjeh
201 - uspjeh (kreirano)
204 - uspjeh (nema sadržaja)

300 - redirect
301 - trajni redirect
302 - privremeni redicert

400 - Error kod klijenta (Bad request)
401 - neautoriziran zahtjev
403 - zabranjeni zahtjev
404 - zahtjev za nečim što više ne postoji(Not Found)

500 - greške na serveru
*/

/* new XMLHttpRequest().open("GET", "./imena.json") */

const xhr = new XMLHttpRequest();
const metoda = "GET";
const url = "./imena.json";

xhr.open(metoda, url);

xhr.onreadystatechange = function () {
  /*   console.log(this.readyState);
  console.log(this.status);
  console.log(this.response); */
  if (this.readyState === 4 && this.status === 200) {
    /* console.log(JSON.parse(this.response)); */
    const data = JSON.parse(this.response);
    data.forEach((osoba) => {
      const li = document.createElement("li");
      li.innerHTML = `${osoba.ime} ${osoba.prezime} ima ${osoba.godina}`;
      document.querySelector("#imena").appendChild(li);
    });
  }
};

xhr.send();

/* readyState ima 5 mogućih odgovora na zahtjev:

0: zahtjev nije inicijaliziran
1: server konekcija je uspostavljena
2: zahtjev zaprimljen
3: procesuiranje zahtjeva
4: zahtjev je završio i odgovor je spreman
*/

const url2 = "https://api.github.com/users/Igor-sam-svoj-rob/repos";

xhr.open(metoda, url2);

xhr.onreadystatechange = function () {
  if (this.readyState === 4 && this.status === 200) {
    const data = JSON.parse(this.response);
    data.forEach((repo) => {
      const li = document.createElement("li");
      li.innerHTML = `${repo.name}`;
      document.querySelector("#imena").appendChild(li);
    });
  }
};

xhr.send();
