"use strict";

fetch("https://httpstat.us/200")
  .then((res) => {
    if (res.status === 404) {
      throw new Error("Error 404, stranica nije nađena");
    } else if (res.status === 500) {
      throw new Error("Error 500, server nije nađen");
    } else if (res.status === 502) {
      throw new Error("Zahtjev je neuspješan");
    }
    return res;
  })
  .then(() => {
    console.log("uspjeh");
  })
  .catch((error) => {
    console.log(error);
  });
