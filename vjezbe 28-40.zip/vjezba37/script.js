"use strict";

/* const obecanje = new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve({ ime: "Igor", godine: 40 });
  }, 1000);
});

obecanje.then((data) => console.log(data));

async function povuciObecanje() {
  const resolve = await obecanje;
  console.log(resolve);
}

povuciObecanje();

async function dohvatiUsera() {
  const res = await fetch("https://jsonplaceholder.typicode.com/users");
  const data = await res.json();

  console.log(data);
}

dohvatiUsera();

function dohvatiUsera1() {
  fetch("https://jsonplaceholder.typicode.com/users")
    .then((res) => res.json())
    .then((data) => console.log(data));
}

dohvatiUsera1();

const dohvatiUsera2 = async () => {
  const res = await fetch("https://jsonplaceholder.typicode.com/users");
  const data = await res.json();

  console.log(data);
};

dohvatiUsera2(); */

/* try {
  console.log(x);
} catch (error) {
  console.log(error);
}

function dupli(broj) {
  if (isNaN(broj)) {
    throw new Error(`${broj} nije broj`);
  }
  return broj * 2;
}

try {
  const y = dupli(3);
  console.log(y);
} catch (error) {
  console.log(error);
} */

/* const url = "https://jsonplaceholder.typicode.com/users";
let imena = [];

const useri = async () => {
  try {
    const res = await fetch(url);
    const data = await res.json();
    imena = data.map((x) => x.name);
  } catch (error) {
    console.log(error);
  }
};

(async () => {
  await useri();
  console.log(imena);
})(); */

const url = "https://jsonplaceholder.typicode.com/users";
let imena = [];

const podaciAPI = async () => {
  try {
    const res = await fetch(url);
    const data = await res.json();
    return data.map((x) => x.name);
  } catch (error) {
    console.log(error);
    return [];
  }
};

const useri = async () => {
  imena = await podaciAPI();
  console.log(imena);
};

useri();
