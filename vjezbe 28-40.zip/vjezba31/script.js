"use strict";

/* Promise zapisan u varijabli */

/* const promise = new Promise((resolve, reject) => {
  setTimeout(() => {
    console.log("Async zadatak je dovršen");
    resolve();
  }, 1000);
});

promise.then(() => {
  console.log("promise dovršen..");
});

console.log("Pozz iz globalnog scopea"); */

/* Promise kao anonimna funkcija */

/* new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve({ ime: "Igor", dob: 40 });
  }, 1000);
}).then((osoba) => console.log(`${osoba.ime} ima ${osoba.dob} godina`)); */

/* Primjer sa reject stanjem */

/* const dohvatiKorisnika = new Promise((resolve, reject) => {
  setTimeout(() => {
    let greska = false;

    if (!greska) {
      resolve({ ime: "Igor", dob: 40 });
    } else {
      reject("Nešto je pošlo po krivu");
    }
  }, 1000);
});

dohvatiKorisnika
  .then((osoba) => console.log(`${osoba.ime} ima ${osoba.dob} godina`))
  .catch((error) => console.log(error))
  .finally(() =>
    console.log("Obećanje je ili prošlo ili nije, ja ću se svejedno ispisati")
  );

console.log("pozz iz globalnog scopea"); */

/* Kreiranje novog objekta liste i ubacivanje u listu i ispis nove liste objekata pomoću callback funkcije. */

/* const imena = [
  { ime: "Ivan", prezime: "Ivić" },
  { ime: "Marko", prezime: "Markić" },
];

const kreirajIme = (ime, cb) => {
  setTimeout(() => {
    imena.push(ime);
    cb();
  }, 2000);
};

const getImena = () => {
  setTimeout(() => {
    imena.forEach((osoba) => {
      const div = document.createElement("div");
      div.innerHTML = `<strong>${osoba.ime} ${osoba.prezime}</strong>`;
      document.querySelector("#imena").appendChild(div);
    });
  }, 1000);
};

kreirajIme({ ime: "Iva", prezime: "Ivić" }, getImena); */

/* Ista stvar samo ćemo umjesto callback funkcije upotrijebiti Promise */

const imena = [
  { ime: "Ivan", prezime: "Ivić" },
  { ime: "Marko", prezime: "Markić" },
];

const kreirajIme = (ime) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      let error = false;
      if (!error) {
        imena.push(ime);
        resolve();
      } else {
        reject("Nešto je pošlo po krivu");
      }
    }, 2000);
  });
};

const getImena = () => {
  setTimeout(() => {
    imena.forEach((osoba) => {
      const div = document.createElement("div");
      div.innerHTML = `<strong>${osoba.ime} ${osoba.prezime}</strong>`;
      document.querySelector("#imena").appendChild(div);
    });
  }, 1000);
};

const pokaziError = (error) => {
  const p = document.createElement("p");
  p.innerHTML = `<strong>${error}<strong>`;
  document.querySelector("#imena").appendChild(p);
};

kreirajIme({ ime: "Iva", prezime: "Ivić" }).then(getImena).catch(pokaziError);

/* Promise chaining */

const promise = new Promise((resolve, reject) => {
  setTimeout(() => {
    let error = false;

    if (!error) {
      resolve({ ime: "Luka", prezime: "Lukić" });
    } else {
      reject("Greška, nešto je pošlo po krivu");
    }
  }, 1000);
});

promise
  .then((osoba) => {
    return osoba.ime;
  })
  .then((ime) => {
    return ime.length;
  })
  .then((duzina) => {
    console.log(duzina);
  })
  .catch((greska) => {
    console.log(greska);
  });
