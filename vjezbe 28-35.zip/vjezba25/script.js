"use strict";

let brojac = 0;

const smanji = document.querySelector("#smanji");
const povecaj = document.querySelector("#povecaj");

smanji.addEventListener("click", () => {
  promijeniBrojac(-1);
});
povecaj.addEventListener("click", () => {
  promijeniBrojac(1);
});

let promijeniBrojac = (broj) => {
  brojac += broj;
  document.querySelector("p").textContent = brojac;
};
