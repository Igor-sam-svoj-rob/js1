"use strict";

const izmjena = (e) => {
  e.target.classList.toggle("crvena");
};

document.querySelector("button").addEventListener("click", izmjena);

const imena = [
  { ime: "Ivan", prezime: "Ivić" },
  { ime: "Maja", prezime: "Majić" },
];

const kreirajIme = (ime, cb) => {
  setTimeout(() => {
    imena.push(ime);
    cb();
  }, 2000);
};

const dohvatiImena = () => {
  setTimeout(() => {
    imena.forEach((ime) => {
      const paragraf = document.createElement("p");
      paragraf.innerHTML = `<strong>${ime.ime} ${ime.prezime}</strong>`;
      document.querySelector("#imena").appendChild(paragraf);
    });
  }, 1000);
};

kreirajIme({ ime: "Ana", prezime: "Anić" }, dohvatiImena);
