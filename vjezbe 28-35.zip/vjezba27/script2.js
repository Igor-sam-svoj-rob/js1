"use strict";

let intervalBoja;

let promijeniBoju = () => {
  if (document.body.style.backgroundColor !== "black") {
    document.body.style.backgroundColor = "black";
    document.body.style.color = "white";
  } else {
    document.body.style.backgroundColor = "white";
    document.body.style.color = "black";
  }
};

document.getElementById("pokreni").addEventListener("click", () => {
  intervalBoja = setInterval(promijeniBoju, 1000);
});

document.getElementById("zaustavi").addEventListener("click", () => {
  clearInterval(intervalBoja);
});
