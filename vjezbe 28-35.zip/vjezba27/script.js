"use strict";

/* Ovo je primjer klasičnog objekta */
const post = {
  id: 1,
  naslov: "Prvi post",
  sadrzaj: "Ovo je sadržaj posta",
  autor: "Igor",
};

/* Prebacivanje objekta u JSON tip podatka (koji je string) */
const jsonFormat = JSON.stringify(post);
/* console.log(post);
console.log(jsonFormat); */

/* Prebacivanje JSON tipa podatka u objekt */
const objektFormat = JSON.parse(jsonFormat);
/* console.log(objektFormat); */

/* setTimeout(() => {
  console.log("pozz iz setTimeouta");
}, 0);

console.log("pozz izvan setTimeouta"); */

/* SetTimeout se izvodi nakon određenog vremena, jednom. */

const promijeniText = () => {
  document.getElementById("naslov").textContent =
    "pozz iz setTimeout callback funkcije";
};

const promjena = setTimeout(promijeniText, 4000);

document.getElementById("stop").addEventListener("click", () => {
  clearTimeout(promjena);
  console.log("Otkazali smo izvođenje setTimeout funkcije");
});

/* SetInterval se izvodi konstantno bez kraja */

const znak = () => {
  console.log("SetInterval funkcija se okinula");
};

const interval = setInterval(znak, 1000);

document.getElementById("zaustavi").addEventListener("click", () => {
  clearInterval(interval);
});
