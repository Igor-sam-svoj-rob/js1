"use strict";

function changeColor() {
  const hexBrojevi = [
    "0",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "a",
    "b",
    "c",
    "d",
    "e",
    "f",
  ];

  let hexCode = "";
  for (let i = 0; i < 6; i++) {
    hexCode += hexBrojevi[Math.floor(Math.random() * hexBrojevi.length)];
  }
  document.querySelector("span").textContent = hexCode;
  document.body.style.backgroundColor = "#" + hexCode;
}

const broj = document.querySelector("button");
broj.addEventListener("click", changeColor);
