"use strict";

/* 1. složi varijablu tajniBroj i u tu varijablu spremi random broj između 1 i 21.
2. Postavi broj pokušaja kao varijablu score i početne vrijednosti 20 (let score = 20)
3. Postavi varijablu highscore i postavi početnu vrijednost 0 (let highscore = 0)
4. Složi eventListner na input polje i napravi usporedbe sa tajnimBrojem. Ako je input broj veći
od tajnog broja ispiši poruku da broj manji od vašeg, ako je manji onda da je broj veći od vašeg.
Naravno ako se pogodi broj onda ispiši da je broj pogođen. Uzmite u obzir i da treba ispisati poruku
ako broj nije upisan u input polje a pokrenuo se eventListener. Također prilikom svakog promašaja
treba promijeniti i ispis Broja pokušaja (umanjiti za 1). Ako se ispucaju svi pokušaji a nema pogotka
treba ispisati poruku Izgubili ste.
5. Ako ste pogodili broj, treba promijeniti pozadinu u zelenu, umjesto upitnika ispisati tajniBroj i
trenutni broj pokušaja usporediti sa najboljim rezultatom, ako je veći onda ga zapisati umjesto
trenutno postavljenog najboljeg rezultata. (slika je priložena kako bi trebalo izgledati).
6. Pritiskom na gumb ponovo! treba resetirati sve (uključujući novi tajniBroj) osim najboljeg
rezultata. */
